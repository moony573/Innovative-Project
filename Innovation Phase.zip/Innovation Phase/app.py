# app.py
from flask import Flask, render_template, request, redirect, url_for
import requests
from bs4 import BeautifulSoup
import re
import tldextract
from urllib.parse import urlparse

app = Flask(__name__)

# --- Helper detection functions ---

def fetch_page(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (WebPrivacyInspector/1.0)"
    }
    try:
        resp = requests.get(url, headers=headers, timeout=8, allow_redirects=True)
        return resp
    except Exception as e:
        return None

def normalize_url(url):
    if not url.startswith(('http://','https://')):
        url = 'http://' + url
    return url

def is_external(resource_url, base_domain):
    try:
        parsed = urlparse(resource_url)
        if not parsed.netloc:
            return False
        ext = tldextract.extract(parsed.netloc)
        domain = f"{ext.domain}.{ext.suffix}" if ext.suffix else ext.domain
        return domain and domain != base_domain
    except:
        return True

# Patterns mapping -> info type and suggested risk
PATTERNS = {
    "Email": r'input[^>]+type=["\']?email|mailto:',
    "Password": r'input[^>]+type=["\']?password',
    "Phone": r'input[^>]+name=["\']?(phone|mobile)|input[^>]+type=["\']?tel',
    "Location": r'maps\.googleapis|geolocation|navigator\.geolocation|latlng|longitude|latitude',
    "Cookies": r'Set-Cookie',
    "Device Info": r'navigator\.userAgent|userAgent|devicePixelRatio',
    "IP Address": r'api\.ipify|ipinfo|ip-api|whatismyip',
    "Camera/Mic": r'getUserMedia|mediaDevices|camera|microphone'
}

def detect_information_types(html_text, headers, base_domain):
    summary = []
    lowered = html_text.lower() if html_text else ""
    for info_type, pattern in PATTERNS.items():
        found = bool(re.search(pattern, html_text, re.IGNORECASE)) or \
                (info_type == "Cookies" and "set-cookie" in (h.lower() for h in headers.keys()))
        source = None
        if found:
            # find a short snippet for source context
            m = re.search(pattern, html_text, re.IGNORECASE)
            if m:
                snippet = m.group(0)
                source = snippet[:120]
            else:
                # for cookies, use header content
                if info_type == "Cookies":
                    source = headers.get("Set-Cookie", "Set-Cookie header present")
                else:
                    source = "Detected in page or headers"
        risk = "Low"
        if info_type in ["Password", "IP Address", "Camera/Mic"]:
            risk = "High" if found else "Low"
        elif info_type in ["Email", "Location", "Device Info", "Phone"]:
            risk = "Medium" if found else "Low"

        summary.append({
            "type": info_type,
            "detected": found,
            "source": source if source else "—",
            "risk": risk
        })
    return summary

def detect_external_resources(soup, base_domain):
    resources = set()
    scripts = [tag.get('src') for tag in soup.find_all('script') if tag.get('src')]
    imgs = [tag.get('src') for tag in soup.find_all('img') if tag.get('src')]
    links = [tag.get('href') for tag in soup.find_all('link') if tag.get('href')]
    iframes = [tag.get('src') for tag in soup.find_all('iframe') if tag.get('src')]
    all_res = scripts + imgs + links + iframes
    ext_res = []
    for r in all_res:
        if r:
            r = r.strip()
            # ignore data: URIs
            if r.startswith('data:'):
                continue
            try:
                if r.startswith('//'):
                    r = 'http:' + r
                if r.startswith('/'):
                    # relative - skip as external
                    continue
                if r.startswith('http'):
                    if is_external(r, base_domain):
                        ext_res.append(r)
            except:
                continue
    # basic classifier for known trackers
    trackers = []
    known = ['google-analytics','googletagmanager','facebook','doubleclick','ads','analytics','hotjar','mixpanel','segment']
    for r in set(ext_res):
        if any(k in r.lower() for k in known):
            trackers.append(r)
    return list(set(ext_res)), trackers

def compute_privacy_score(summary, external_resources, uses_https):
    score = 100
    # deduct for risky findings
    for item in summary:
        if item['detected']:
            if item['risk'] == "High":
                score -= 20
            elif item['risk'] == "Medium":
                score -= 10
            else:
                score -= 5
    # deduct for number of external resources (trackers)
    score -= min(len(external_resources) * 2, 30)
    if not uses_https:
        score -= 25
    # clamp
    score = max(0, min(100, score))
    return score

# Route: home page
@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

# Route: scan
@app.route('/scan', methods=['POST'])
def scan():
    url = request.form.get('url', '').strip()
    if not url:
        return redirect(url_for('index'))
    url = normalize_url(url)
    resp = fetch_page(url)
    if resp is None:
        return render_template('result.html', error="Could not fetch the URL. Check URL or your internet.", inspected_url=url)

    html = resp.text or ""
    headers = resp.headers or {}
    parsed = urlparse(resp.url)
    ext = tldextract.extract(parsed.netloc)
    base_domain = f"{ext.domain}.{ext.suffix}" if ext.suffix else ext.domain

    uses_https = parsed.scheme == 'https'
    soup = BeautifulSoup(html, "html.parser")

    # Detect information types
    info_summary = detect_information_types(html, headers, base_domain)

    # External resources and trackers
    external_resources, trackers = detect_external_resources(soup, base_domain)

    # Cookies
    cookies = headers.get('Set-Cookie')
    cookies_list = []
    if cookies:
        # split naive by comma for display (simple)
        cookies_list = [c.strip() for c in cookies.split(',') if c.strip()]

    # Privacy score
    privacy_score = compute_privacy_score(info_summary, external_resources, uses_https)

    result = {
        "inspected_url": resp.url,
        "uses_https": uses_https,
        "status_code": resp.status_code,
        "info_summary": info_summary,
        "external_resources": external_resources,
        "trackers": trackers,
        "cookies": cookies_list,
        "privacy_score": privacy_score
    }

    return render_template('result.html', **result)

if __name__ == '__main__':
    app.run(debug=True)
